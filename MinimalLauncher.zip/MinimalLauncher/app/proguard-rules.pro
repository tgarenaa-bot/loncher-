# Keep ViewModel classes so ProGuard doesn't remove them
-keep class com.rushi.minimallauncher.viewmodel.** { *; }

# Keep data model
-keep class com.rushi.minimallauncher.model.** { *; }
