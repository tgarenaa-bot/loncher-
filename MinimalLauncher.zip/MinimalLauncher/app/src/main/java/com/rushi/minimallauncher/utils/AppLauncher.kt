package com.rushi.minimallauncher.utils

import android.content.Context
import android.widget.Toast

/**
 * Handles launching an installed app safely.
 * Wrapping launch logic here keeps MainActivity clean.
 */
object AppLauncher {

    /**
     * Attempts to launch the app with the given [packageName].
     *
     * PackageManager.getLaunchIntentForPackage() returns null if:
     *   - The app was uninstalled between loading and tapping
     *   - The app has no launchable activity (e.g., a library/service-only app)
     *
     * We handle null gracefully with a toast instead of crashing.
     */
    fun launch(context: Context, packageName: String) {
        val pm = context.packageManager
        val launchIntent = pm.getLaunchIntentForPackage(packageName)

        if (launchIntent != null) {
            context.startActivity(launchIntent)
        } else {
            // Graceful fallback — inform user instead of crashing
            Toast.makeText(context, "Cannot open this app", Toast.LENGTH_SHORT).show()
        }
    }
}
