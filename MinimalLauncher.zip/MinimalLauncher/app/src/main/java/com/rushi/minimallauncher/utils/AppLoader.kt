package com.rushi.minimallauncher.utils

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import com.rushi.minimallauncher.model.AppInfo

/**
 * Utility object responsible for querying the device's PackageManager
 * and returning a sorted list of launchable apps.
 *
 * Kept as a plain object (no Android dependencies stored) so it's easy
 * to test and reuse.
 */
object AppLoader {

    /**
     * Returns all apps that have a LAUNCHER intent (i.e., apps the user
     * can normally open from their home screen).
     *
     * Excludes our own launcher app so it doesn't appear in the grid.
     *
     * This can be slow on first call — always run it on a background thread
     * (the ViewModel handles this via coroutines).
     */
    fun getInstalledApps(context: Context): List<AppInfo> {
        val pm = context.packageManager

        // ACTION_MAIN + CATEGORY_LAUNCHER = all apps that appear on home screens
        val intent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }

        // queryIntentActivities returns all activities matching the intent
        // Use MATCH_ALL flag to ensure we get everything (Android 11+)
        val resolvedApps = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)

        val ourPackage = context.packageName   // exclude our own launcher

        return resolvedApps
            .filter { it.activityInfo.packageName != ourPackage }   // skip self
            .map { resolveInfo ->
                AppInfo(
                    name = resolveInfo.loadLabel(pm).toString(),
                    packageName = resolveInfo.activityInfo.packageName,
                    icon = resolveInfo.loadIcon(pm)
                )
            }
            .sortedBy { it.name.lowercase() }   // alphabetical, case-insensitive
    }
}
