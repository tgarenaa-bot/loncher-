package com.rushi.minimallauncher.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.rushi.minimallauncher.model.AppInfo
import com.rushi.minimallauncher.utils.AppLoader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * ViewModel survives screen rotations and configuration changes.
 * It loads apps once and exposes them to the UI via LiveData.
 *
 * Using AndroidViewModel (not plain ViewModel) because we need
 * the Application context to call PackageManager.
 */
class LauncherViewModel(application: Application) : AndroidViewModel(application) {

    // Full list of installed apps (loaded once, never changes unless refreshed)
    private val _allApps = MutableLiveData<List<AppInfo>>()

    // Filtered list that the UI actually observes
    private val _filteredApps = MutableLiveData<List<AppInfo>>()
    val filteredApps: LiveData<List<AppInfo>> = _filteredApps

    // Loading state so the UI can show a progress indicator
    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    // Track current search query (preserved across rotations)
    private var currentQuery = ""

    init {
        loadApps()
    }

    /**
     * Loads apps in the background (IO thread) then posts to LiveData
     * on the main thread. viewModelScope is automatically cancelled
     * when the ViewModel is destroyed.
     */
    fun loadApps() {
        viewModelScope.launch {
            _isLoading.value = true

            val apps = withContext(Dispatchers.IO) {
                // AppLoader.getInstalledApps can take 200-500ms on slow devices
                AppLoader.getInstalledApps(getApplication())
            }

            _allApps.value = apps
            applyFilter(currentQuery)   // re-apply any active search
            _isLoading.value = false
        }
    }

    /**
     * Called whenever the user types in the search bar.
     * Filters app names case-insensitively.
     * Empty query → show all apps.
     */
    fun search(query: String) {
        currentQuery = query
        applyFilter(query)
    }

    private fun applyFilter(query: String) {
        val all = _allApps.value ?: return

        _filteredApps.value = if (query.isBlank()) {
            all
        } else {
            all.filter { app ->
                app.name.contains(query, ignoreCase = true)
            }
        }
    }
}
