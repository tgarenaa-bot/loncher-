package com.rushi.minimallauncher.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.rushi.minimallauncher.databinding.ItemAppBinding
import com.rushi.minimallauncher.model.AppInfo

/**
 * RecyclerView Adapter using ListAdapter + DiffUtil.
 *
 * Why ListAdapter?
 *   - Automatically calculates what changed between two lists
 *   - Only redraws items that actually changed (better performance)
 *   - Built-in async diffing on a background thread
 *
 * @param onAppClick  Lambda called when user taps an app icon
 */
class AppGridAdapter(
    private val onAppClick: (AppInfo) -> Unit
) : ListAdapter<AppInfo, AppGridAdapter.AppViewHolder>(AppDiffCallback()) {

    // -------------------------------------------------------------------------
    // ViewHolder — holds references to the views for ONE grid item
    // -------------------------------------------------------------------------
    inner class AppViewHolder(
        private val binding: ItemAppBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(app: AppInfo) {
            // Set icon and name
            binding.appIcon.setImageDrawable(app.icon)
            binding.appName.text = app.name

            // Trigger launch on tap
            binding.root.setOnClickListener {
                onAppClick(app)
            }
        }
    }

    // -------------------------------------------------------------------------
    // Adapter overrides
    // -------------------------------------------------------------------------

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AppViewHolder {
        // Inflate using ViewBinding — safer than findViewById
        val binding = ItemAppBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return AppViewHolder(binding)
    }

    override fun onBindViewHolder(holder: AppViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    // -------------------------------------------------------------------------
    // DiffUtil — tells RecyclerView what changed between two lists
    // -------------------------------------------------------------------------
    class AppDiffCallback : DiffUtil.ItemCallback<AppInfo>() {

        // Two items are the "same" if they represent the same app
        override fun areItemsTheSame(oldItem: AppInfo, newItem: AppInfo): Boolean {
            return oldItem.packageName == newItem.packageName
        }

        // Two items have the "same content" if nothing changed (name, icon, etc.)
        override fun areContentsTheSame(oldItem: AppInfo, newItem: AppInfo): Boolean {
            return oldItem.name == newItem.name &&
                    oldItem.packageName == newItem.packageName
        }
    }
}
